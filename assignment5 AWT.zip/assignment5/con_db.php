<?php 
	$host='localhost';
	$uname='root';
	$pwd='';
	$db='p5';

	$con=mysqli_connect($host,$uname,$pwd);
	mysqli_select_db($con,$db);



 ?>